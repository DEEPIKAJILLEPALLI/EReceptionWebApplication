import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { CustomerValidator, DateValidator } from '../validator.service';
import { EReception } from '../Ereception.model';
import { ReceptionService } from '../reception.service';
import { MatTableDataSource } from '@angular/material';
@Component({
  selector: 'app-reception-form',
  templateUrl: './reception-form.component.html',
  styleUrls: ['./reception-form.component.css']
})
export class ReceptionFormComponent implements OnInit {
  // visitorList: EReception[];
  // @Input() dataSource = new MatTableDataSource<EReception>();
  // // tslint:disable-next-line:no-inferrable-types
  // public reload: boolean = false;
  OutTime: string;
  visitorFormGroup: FormGroup;
  visitor: EReception;
  // @Output() vis = new EventEmitter<EReception>();
  @Output() vistoradded = new EventEmitter<EReception>();
  private dateTime = new Date();
  // dateTime=new Date();
  hour = 0; minute = 0; second = 0;
  inTime: string;
  outTime: string;


  constructor(private rs: ReceptionService,
    private Validator: CustomerValidator, private dateValidator: DateValidator, private _formBuilder: FormBuilder) {
    this.visitorFormGroup = this._formBuilder.group({
      name: ['', Validators.required],
      mobile: ['', Validators.required],
      email: ['', this.Validator.formEmailValidator],
      tomeet: ['', Validators.required],
      purpose: ['', Validators.required],
      address: ['', Validators.required]

    });
  }

  ngOnInit() {

  }
  onSubmit() {
    if (this.visitorFormGroup.valid) {
      this.visitor = this.visitorFormGroup.value;

      console.log(this.visitor);
      // this.visitor.Id = 11;
      this.hour = this.dateTime.getHours();
      this.minute = this.dateTime.getMinutes();
      this.second = this.dateTime.getSeconds();
      this.inTime = '' + this.hour + ':' + this.minute;
      console.log(this.inTime);
      this.visitor.InTime = this.inTime;
      this.visitor.OutTime = this.OutTime;
      console.log('outtime:' + this.visitor.OutTime);
      this.vistoradded.emit(this.visitor);

    }

  }
  // tslint:disable-next-line:use-life-cycle-interface
  // public ngOnChanges(): void {
  //   if (this.reload) {
  //     this.loadOrdersAsync();
  //   }
  // }
  // private async loadOrdersAsync() {
  //   this.visitorList = await this.rs.getVisitorList().toPromise();
  //   this.dataSource.data = this.visitorList;
  //   console.log('form submitted' + this.dataSource.data);
  // }
}
