import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { EReception } from '../Ereception.model';
import { ReceptionService } from '../reception.service';

@Component({
  selector: 'app-visitor-info',
  templateUrl: './visitor-info.component.html',
  styleUrls: ['./visitor-info.component.css']
})
export class VisitorInfoComponent implements OnInit {
  minute: number;
  hour: number;
  @Output() outtime = new EventEmitter<EReception>();
  @Input()
  public visitor: EReception;
  //  @Output() logout = new EventEmitter<EReception>();
  private dateTime = new Date();
  constructor(private rs: ReceptionService) {

  }
  ngOnInit() {
  }
  Logout(visitor: EReception) {
    if (this.visitor.OutTime !== '') {
      this.hour = this.dateTime.getHours();
      this.minute = this.dateTime.getMinutes();
      this.visitor.OutTime = '' + this.hour + ':' + this.minute;
// this.outtime.emit(this.visitor);
      this.rs.putVisitorTime(this.visitor).toPromise();
    }

  }

}
