import { Time } from '@angular/common';

export class EReception {
    id: number;
    Name: string;
    Mobile: string;
    Email: string;
    Address: string;
    Purpose: string;
    ToMeet: string;
    InTime: string;
    OutTime: string;

}
