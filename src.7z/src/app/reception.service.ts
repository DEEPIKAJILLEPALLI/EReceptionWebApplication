import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EReception } from './Ereception.model';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
@Injectable()
export class ReceptionService {
    constructor(private http: HttpClient) { }
    postVisitor(reception: EReception): Observable<EReception> {
        return this.http.post<EReception>('http://localhost:50343/api/reception/newvisitor', reception);
    }
    putVisitor(id, visitor): Observable<EReception> {
        return this.http.put<EReception>('http://localhost:50343/api/reception/updatevisitor/',
            visitor);
    }

    putVisitorTime(visitor): Observable<EReception> {
        return this.http.put<EReception>('http://localhost:50343/api/reception/updatevisitorOutTime/',
            visitor);
    }

    getVisitorList(): Observable<EReception[]> {
        return this.http.get('http://localhost:50343/api/reception/visitors')
            .pipe(map(res => <EReception[]>res));
    }
    getVisitorListById(id: number): Observable<EReception[]> {
        return this.http.get('http://localhost:50343/api/reception/visitors/' + id)
            .pipe(map(res => <EReception[]>res));
    }

    deleteVisitor(id: number) {
        return this.http.delete('http://localhost:50343/api/reception/deleteVisitor/' + id);
    }
}
