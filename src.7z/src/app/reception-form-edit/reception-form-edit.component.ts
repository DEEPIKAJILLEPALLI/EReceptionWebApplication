import { Component, OnInit, EventEmitter, Output, Input } from '@angular/core';
import { CustomerValidator, DateValidator } from '../validator.service';
import { ReceptionService } from '../reception.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { EReception } from '../Ereception.model';
import { MatTableDataSource } from '@angular/material';

@Component({
  selector: 'app-reception-form-edit',
  templateUrl: './reception-form-edit.component.html',
  styleUrls: ['./reception-form-edit.component.css']
})
export class ReceptionFormEditComponent implements OnInit {
  visitorFormGroup: FormGroup;
  visitor: EReception;
  @Output() vis = new EventEmitter<EReception>();
  private dateTime = new Date();

  // dateTime=new Date();
  hour = 0; minute = 0; second = 0;
  inTime: string;
  outTime: string;

  id: number;
  name: string;
  mobile: string;
  email: string;
  purpose: string;
  address: string;
  tomeet: string;
  in_time: string;
  out_time: string;




  constructor(private rs: ReceptionService,
    private Validator: CustomerValidator, private dateValidator: DateValidator, private _formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.visitorFormGroup = this._formBuilder.group({
      Id: [this.id],
      name: [this.name, Validators.required],
      mobile: [this.mobile, Validators.required],
      address: [this.address, Validators.required],
      email: [this.email, this.Validator.formEmailValidator],
      tomeet: [this.tomeet, Validators.required],
      purpose: [this.purpose, Validators.required]
    });
  }
  onSubmit() {
    if (this.visitorFormGroup.valid) {
      // this.vis = this.visitorFormGroup.value;
      this.visitor = this.visitorFormGroup.value;
      console.log(this.vis);
      this.hour = this.dateTime.getHours();
      this.minute = this.dateTime.getMinutes();
      this.second = this.dateTime.getSeconds();
      this.inTime = '' + this.hour + ':' + this.minute;
      console.log(this.inTime);
      this.visitor.InTime = this.inTime;
      this.visitor.OutTime = this.outTime;
      this.vis.emit(this.visitor);
    }
  }

}
