import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceptionFormEditComponent } from './reception-form-edit.component';

describe('ReceptionFormEditComponent', () => {
  let component: ReceptionFormEditComponent;
  let fixture: ComponentFixture<ReceptionFormEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReceptionFormEditComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceptionFormEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
