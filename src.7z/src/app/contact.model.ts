
export class Contact {
    // Firstname: string;
    // Lastname: string;
    // Dob: string;
    // Email: string;
    // Phno: number;
    // hno: string;
    // street: string;
    // city: string;
    // district: string;
    // pin: number;
    Id: number;
    name: string;
    email: string;

}
