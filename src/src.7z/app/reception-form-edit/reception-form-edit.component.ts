import { Component, OnInit } from '@angular/core';
import { CustomerValidator, DateValidator } from '../validator.service';
import { ReceptionService } from '../reception.service';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
import { EReception } from '../Ereception.model';

@Component({
  selector: 'app-reception-form-edit',
  templateUrl: './reception-form-edit.component.html',
  styleUrls: ['./reception-form-edit.component.css']
})
export class ReceptionFormEditComponent implements OnInit {

  visitorFormGroup: FormGroup;
  visitor: EReception;
  private dateTime = new Date();
  // dateTime=new Date();
  hour = 0; minute = 0; second = 0;
  inTime: string;
  outTime: string;

  id: number;
  name: string;
  mobile: string;
  email: string;
  purpose: string;
  address: string;
  tomeet: string;
  in_time: string;
  out_time: string;




  constructor(private rs: ReceptionService,
    private Validator: CustomerValidator, private dateValidator: DateValidator, private _formBuilder: FormBuilder) {
  }

  ngOnInit() {
    this.visitorFormGroup = this._formBuilder.group({
      Id: [this.id],
      name: [this.name, Validators.required],
      mobile: [this.mobile, Validators.required],
      email: [this.email, this.Validator.formEmailValidator],
      tomeet: [this.tomeet, Validators.required],
      purpose: [this.purpose, Validators.required]
    });
  }
  onSubmit() {
    if (this.visitorFormGroup.valid) {
      this.visitor = this.visitorFormGroup.value;

      console.log(this.visitor);
      // this.visitor.Id = 11;
      this.hour = this.dateTime.getHours();
      this.minute = this.dateTime.getMinutes();
      this.second = this.dateTime.getSeconds();
      this.inTime = '' + this.hour + ':' + this.minute;
      console.log(this.inTime);
      this.visitor.InTime = this.inTime;
      this.visitor.OutTime = this.outTime;
      const putvisitor = this.rs.putVisitor(this.id, this.visitor).subscribe(async data => {
        console.log(data);
        if (putvisitor) {
          console.log(await this.rs.getVisitorList().toPromise());
        }
        });
    } else {
      alert('Invalid data.');
      console.log(this.visitorFormGroup);

    }
  }
}
