import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ReceptionService } from '../reception.service';
import { EReception } from '../Ereception.model';
import { MatTableDataSource } from '@angular/material';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-reception-list',
  templateUrl: './reception-list.component.html',
  styleUrls: ['./reception-list.component.css']
})
export class ReceptionListComponent implements OnInit {
  @Input()
    // tslint:disable-next-line:no-inferrable-types
    public reload: boolean = false;
  visitorList: EReception[];
  displayedColumns = ['Id', 'Name', 'Email', 'Mobile', 'Address', 'Purpose', 'ToMeet', 'InTime', 'OutTime'];
  @Input() dataSource;
  public selectedRow$ = new BehaviorSubject<EReception>(null);
  // tslint:disable-next-line:no-output-on-prefix
  @Output()
  public onVisitorSelection = new EventEmitter<EReception>();

  constructor(private vs: ReceptionService) { }

  async ngOnInit() {
    this.visitorList = await this.vs.getVisitorList().toPromise();
    this.dataSource = new MatTableDataSource(this.visitorList);
  }
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim(); // Remove whitespace
    filterValue = filterValue.toLowerCase(); // MatTableDataSource defaults to lowercase matches
    this.dataSource.filter = filterValue;
  }
  // tslint:disable-next-line:use-life-cycle-interface
  public ngOnChanges(): void {
    if (this.reload) {
        this.loadOrdersAsync();
    }
}
private async loadOrdersAsync() {
  this.visitorList = await this.vs.getVisitorList().toPromise();
}
  public async onSelectRow(row: EReception): Promise<void> {
    this.selectedRow$.next(row);
    this.onVisitorSelection.emit(row);
    console.log(row);
}

}
