// import { Injectable } from '@angular/core';
// import { Http, Response } from '@angular/Http';
// import { Observable } from 'rxjs/Observable';
// import { Contact } from './contact.model';
// import 'rxjs/add/operator/map';

// @Injectable()
// export class ContactService {
//     constructor(private _http: Http) {

//     }
//     getcontacts(): Observable<Contact[]> {
//         return this._http.get('http://localhost:62247/api/Student').map((response: Response) => <Contact[]>response.json());
//     }

// }


import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod } from '@angular/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { Contact } from './contact.model';
import { HttpClient } from '@angular/common/http';


@Injectable()
export class ContactService {
    constructor(private http: HttpClient) { }

    postContact(contact: Contact): Observable<Contact> {
        return this.http.post<Contact>('http://localhost:62247/api/Student/PostNewStudent', contact);
    }
    putContact(id, contact): Observable<Contact> {
        return this.http.put<Contact>('http://localhost:62247/api/Student/' + id,
            contact);
    }

    getContactList(): Observable<Contact[]> {
        return this.http.get('http://localhost:62247/api/Student/')
            .pipe(map(res => <Contact[]>res));
    }
    getContactListById(id: number): Observable<Contact[]> {
        return this.http.get('http://localhost:62247/api/Student/GetStudentById' + id)
            .pipe(map(res => <Contact[]>res));
    }

    deleteContact(id: number) {
        return this.http.delete('http://localhost:62247/api/Student/' + id);
    }
}
