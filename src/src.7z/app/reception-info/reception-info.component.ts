import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reception-info',
  templateUrl: './reception-info.component.html',
  styleUrls: ['./reception-info.component.css']
})
export class ReceptionInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
