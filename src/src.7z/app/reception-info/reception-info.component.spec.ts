import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReceptionInfoComponent } from './reception-info.component';

describe('ReceptionInfoComponent', () => {
  let component: ReceptionInfoComponent;
  let fixture: ComponentFixture<ReceptionInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReceptionInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReceptionInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
