import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { ReceptionFormComponent } from '../reception-form/reception-form.component';
import { MatDialog } from '@angular/material';
import { ReceptionFormEditComponent } from '../reception-form-edit/reception-form-edit.component';
import { EReception } from '../Ereception.model';
import { ReceptionService } from '../reception.service';

@Component({
  selector: 'app-reception-view',
  templateUrl: './reception-view.component.html',
  styleUrls: ['./reception-view.component.css']
})
export class ReceptionViewComponent implements OnInit {

  // tslint:disable-next-line:no-inferrable-types
  reloadVisitors: boolean = false;
  visitorList: any;
  items: EReception[];
  public visitors: EReception[];
  selectedvisitor: EReception = null;
  public currentVId: number = null;
  currentVisitor: EReception;
  @Output() VisitortSelect: EventEmitter<EReception>;
  constructor(public dialog: MatDialog, public vs: ReceptionService) { }
  ngOnInit() {
    // this.visitors = await this.vs.getVisitorList().toPromise();
  }
  openFormDialog(): void {
    // tslint:disable-next-line:prefer-const
    let dialogRef = this.dialog.open(ReceptionFormComponent, {
      width: '500px',
      height: '500px',
      position: { top: '200px', bottom: '50px' },
    });
    // dialogRef.componentInstance.user = this.user;

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
  openEditDialog(): void {
    // tslint:disable-next-line:prefer-const
    let dialogRef = this.dialog.open(ReceptionFormEditComponent, {
      width: '500px',
      height: '500px',
      position: { top: '200px', bottom: '50px' },
    });
    console.log('edit');
    console.log(this.selectedvisitor);
    const obj = dialogRef.componentInstance;
    obj.id = this.selectedvisitor.id;
    obj.name = this.selectedvisitor.Name;
    obj.email = this.selectedvisitor.Email;
    obj.mobile = this.selectedvisitor.Mobile;
    obj.address = this.selectedvisitor.Address;
    obj.purpose = this.selectedvisitor.Purpose;
    obj.tomeet = this.selectedvisitor.ToMeet;
    console.log('obj');
    console.log(obj);

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }
  async openDeleteDialog() {
    console.log(event);
    const id = this.selectedvisitor.id;
    const deletedContact = await this.vs.deleteVisitor(id).toPromise();
    console.log('delete');
    console.log(deletedContact);
    if (deletedContact) {
      this.reloadVisitors = true;
      this.visitorList = await this.vs.getVisitorList().toPromise();
      console.log(this.visitorList);
    }
  }
  public async setSelectedVisitor(reception: EReception) {
    if (reception) {
      this.selectedvisitor = reception;
      console.log('view');
      console.log(this.selectedvisitor);

    }
  }



}
